<div class="row d-flex justify-content-center pt-3">
   <div class="col-md-10">
      <h1><?= $page_info_by_id->page_title ?></h1>
      <?= $page_info_by_id->page_data ?>
   </div>
</div>